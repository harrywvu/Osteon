# Plans and Features

**Updated:** 2026-11-03

This directory tracks dated feature decisions and their status. See
[G3 inspection](../Docs/G3_INSPECTION.md) for current controls and verification.

| Label | Date | Status | Document |
|---|---|---|---|
| PLAN-001 | 2026-09-09 | Planned; first priority | [Stationary viewing and controller grabbing](2026-09-09_PLAN-001_Stationary-Viewing-and-Grabbing.md) |
| PLAN-002 | 2026-09-09 | Planned; follows PLAN-001 | [Reusable bone-group expansion](2026-09-09_PLAN-002_Bone-Group-Expansion.md) |
| PLAN-003 | 2026-10-06 | Implemented; Quest verification pending | [Skull explosion](2026-10-06_PLAN-003_Skull-Explosion.md) |
| PLAN-004 | 2026-10-07 | Implemented in code; Play Mode and Quest verification pending | [Appearance and text settings](2026-10-07_PLAN-004_Appearance-and-Text-Settings.md) |
| PLAN-005 | 2026-10-07 | Implemented in code; Play Mode and Quest verification pending | [Panel spacing, shared G2 spread, and wall settings](2026-10-07_PLAN-005_Panel-Spacing-Shared-Spread-and-Wall-Settings.md) |
| PLAN-006 | 2026-10-28 | Live account service and HTTP client implemented; live API checks recorded; Quest/WebGL account UI acceptance pending | [Anonymous user accounts for Quest and WebGL](2026-10-28_PLAN-006_Anonymous-User-Accounts.md) |
| PLAN-007 | 2026-11-03 | Account-aware quiz and AI explanations deployed; owner verified WebGL, VR, and cross-device resume; owner reports enabling Gemini-driven adaptation, acceptance pending | [Account-aware AI quiz for Quest and WebGL](2026-11-03_PLAN-007_Account-Aware-AI-Quiz.md) |
| FEATURE-STATUS | 2026-09-09 | Historical snapshot | [Implementation and verification status](2026-09-09_FEATURE-STATUS.md) |

Confirmed user choices for PLAN-001: smooth viewpoint turning, controller-based
grabbing, and bones staying where released. Numerical settings and implementation
details in these plans are proposed starting defaults for later implementation.

Current implementation and validation details are in
[G3 inspection](../Docs/G3_INSPECTION.md). Update this index and the feature
register when work actually starts, ships, or receives additional verification.
