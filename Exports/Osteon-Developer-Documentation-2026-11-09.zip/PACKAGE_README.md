# Osteon developer documentation package

Project owner declared the delivered project complete on 2026-11-09. Start at Docs/DEVELOPER_MANUAL.md and Docs/RELEASE_HANDOFF.md. This archive contains documentation and version references, not the Unity source, built players, deployment packages, or credentials. Paths to source files refer to the companion repository. MANIFEST.sha256 records SHA-256 checksums of packaged repository files.
